import { Link } from 'react-router-dom';
import {
  Mail,
  Phone,
  MapPin,
  Send,
} from 'lucide-react';

const Footer = () => {
  const footerLinks = {
    services: [
      { name: 'Home Services', href: '/categories?type=home' },
      { name: 'Beauty Services', href: '/categories?type=beauty' },
      { name: 'Education', href: '/categories?type=education' },
      { name: 'Technology', href: '/categories?type=tech' },
      { name: 'Vehicle Services', href: '/categories?type=vehicle' },
      { name: 'Health Services', href: '/categories?type=health' },
    ],
    company: [
      { name: 'About Us', href: '/about' },
      { name: 'Careers', href: '/careers' },
      { name: 'Press', href: '/press' },
      { name: 'Blog', href: '/blog' },
      { name: 'Contact', href: '/contact' },
    ],
    support: [
      { name: 'Help Center', href: '/help' },
      { name: 'Safety Center', href: '/safety' },
      { name: 'Community Guidelines', href: '/guidelines' },
      { name: 'Terms of Service', href: '/terms' },
      { name: 'Privacy Policy', href: '/privacy' },
    ],
    providers: [
      { name: 'Become a Provider', href: '/register?type=provider' },
      { name: 'Provider Resources', href: '/provider-resources' },
      { name: 'Success Stories', href: '/success-stories' },
      { name: 'Provider App', href: '/provider-app' },
    ],
  };

  const socialLinks = [
    { name: 'Facebook', href: '#' },
    { name: 'Instagram', href: '#' },
    { name: 'Twitter', href: '#' },
    { name: 'LinkedIn', href: '#' },
    { name: 'YouTube', href: '#' },
  ];

  return (
    <footer className="bg-[#0F172A] text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#3B82F6] to-[#06B6D4] flex items-center justify-center">
                <span className="text-white font-bold text-lg">C</span>
              </div>
              <div>
                <span className="font-bold text-xl text-white">Cheapflix</span>
                <span className="text-sm block -mt-1 text-[#3B82F6]">Nepal</span>
              </div>
            </Link>
            <p className="text-slate-400 text-sm mb-6 leading-relaxed">
              Nepal's leading service marketplace connecting you with trusted local professionals. 
              Book services instantly, pay securely, and get things done.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <a href="mailto:support@cheapflix.np" className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors text-sm">
                <Mail className="w-4 h-4" />
                support@cheapflix.np
              </a>
              <a href="tel:+977-9801234567" className="flex items-center gap-3 text-slate-400 hover:text-white transition-colors text-sm">
                <Phone className="w-4 h-4" />
                +977-9801234567
              </a>
              <div className="flex items-center gap-3 text-slate-400 text-sm">
                <MapPin className="w-4 h-4" />
                Kathmandu, Nepal
              </div>
            </div>

            {/* Social Links */}
            <div className="flex items-center gap-4 mt-6">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-slate-400 hover:bg-[#3B82F6] hover:text-white transition-all text-xs font-medium"
                  aria-label={social.name}
                >
                  {social.name.slice(0, 2)}
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-semibold text-white mb-4">Services</h3>
            <ul className="space-y-3">
              {footerLinks.services.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-slate-400 hover:text-white transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold text-white mb-4">Company</h3>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-slate-400 hover:text-white transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold text-white mb-4">Support</h3>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-slate-400 hover:text-white transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="font-semibold text-white mb-4">Newsletter</h3>
            <p className="text-slate-400 text-sm mb-4">
              Subscribe to get updates on new services and offers.
            </p>
            <div className="relative">
              <input
                type="email"
                placeholder="Your email"
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-[#3B82F6]/50 focus:border-[#3B82F6] transition-all"
              />
              <button className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-[#3B82F6] text-white rounded-lg hover:bg-[#2563EB] transition-colors">
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-slate-500 text-sm text-center md:text-left">
              © {new Date().getFullYear()} Cheapflix Nepal. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <Link to="/terms" className="text-slate-500 hover:text-white transition-colors text-sm">
                Terms
              </Link>
              <Link to="/privacy" className="text-slate-500 hover:text-white transition-colors text-sm">
                Privacy
              </Link>
              <Link to="/cookies" className="text-slate-500 hover:text-white transition-colors text-sm">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
